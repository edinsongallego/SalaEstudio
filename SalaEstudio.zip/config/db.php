<?php
/*Datos de conexion a la base de datos*/
define('DB_HOST', 'localhost');//DB_HOST:  generalmente suele ser "127.0.0.1"
define('DB_USER', 'root');//Usuario de tu base de datos
define('DB_PASS', 'root');//Contraseña del usuario de la base de datos
define('DB_NAME', 'salaestudiodb');//Nombre de la base de datos
 
/*Datos de la empresa*/
define('NOMBRE_EMPRESA', 'LA SALA ESTUDIO');
define('DIRECCION_EMPRESA', 'Medellín');
define('TELEFONO_EMPRESA', '+(57) 2250-5550');
define('EMAIL_EMPRESA', 'info@lasalaestudio.com');
define('BASE_URL', 'http://localhost/SalaEstudio/');
define('TAX', '13');



?>
